<img src="{{ asset('images/BikolpoLive.svg') }}" {{ $attributes }} alt="Bikolpo Live Logo">
